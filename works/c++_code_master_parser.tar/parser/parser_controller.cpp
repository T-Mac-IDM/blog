/***************************************************************************
 * 
 * Copyright (c) 2015 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
 
 
 
/**
 * @file parser_controller.h
 * @author liuzhaocheng(com@baidu.com)
 * @date 2015/08/25 11:00:23
 * @brief 
 *  
 **/

#include "parser/parser_controller.h"

namespace dictp {

size_t ParseController::get_nr() const {
    return _nr == 0 ? _nr : _nr - 1;
}

bool ParseController::eof() {
    if (_parser.eol()) {
        std::string line;
        std::getline(_ifst, line);
        if (_ifst.eof() || _ifst.fail()) {
            return true;
        }
        _lines.push_back(line);

        _parser.reset(line);
        _nr++;
    }
    return false;
}

} // namespace dictParser
