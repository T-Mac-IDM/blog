/***************************************************************************
 * 
 * Copyright (c) 2015 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
 
 
 
/**
 * @file parser_controller.h
 * @author liuzhaocheng(com@baidu.com)
 * @date 2015/08/25 11:00:23
 * @brief 
 *  
 **/

#ifndef  DICTP_PARSER_CONTROLLER_H
#define  DICTP_PARSER_CONTROLLER_H

#include <fstream>
#include <string>
#include <vector>
#include <cassert>
#include "parser/deserialize.h"

namespace dictp {

//parse file to lines , then deserialize one line each time
class ParseController {
public:
    // @param dict_name name of the file to be parsed
    explicit ParseController(const std::string &dict_name) :
         _dict_name(dict_name), _ifst(dict_name.c_str()),
        _nr(0) {}
    ~ParseController() {}

    template<typename T>
    bool parse_support(T* t) {
        if (_parser.eol()) {
            if (_ifst.eof()) {
                return false;
            }
            std::string line;
            std::getline(_ifst, line);
            _lines.push_back(line);

            _parser.reset(line);
            _nr++;
        }
        // if parse failed, then abandon current line and deal with next line.
        if (!_parser.parse_item(t)) {
            std::string line;
            std::getline(_ifst, line);
            _lines.push_back(line);

            _parser.reset(line);
            _nr++;
            return false;
        }
        return true;
    }

    template<typename T>
    bool parse_user(T* t) {
        if (_parser.eol()) {
            if (_ifst.eof()) {
                return false;
            }
            std::string line;
            std::getline(_ifst, line);
            _lines.push_back(line);

            _parser.reset(line);
            _nr++;
        }
        // if parse failed, then abandon current line and deal with next line.
        if (!_parser.parse_user_item(t)) {
            std::string line;
            std::getline(_ifst, line);
            _lines.push_back(line);

            _parser.reset(line);
            _nr++;
            return false;
        }
        return true;
    }
    // get current num of row
    // begin with 0
    size_t get_nr() const;

    // is the end of file
    // @return true only if no data in the dict file and current line has been parsed.
    bool eof();

private:
    std::string _dict_name;
    std::ifstream _ifst;
    size_t _nr;
    std::vector<std::string> _lines;
    Deserialize _parser;
};

} // namespace dictParser

#endif  //DICTP_PARSER_H_
