/***************************************************************************
 *
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 *
 **************************************************************************/

/**
 * @file item_convert.h
 * @author liuzhaocheng(liuzhaocheng@baidu.com)
 * @date 2014/05/16 15:40:50
 * @brief convert item to different type
 *
 **/

#ifndef DICTP_STR_CONVERTOR_H
#define DICTP_STR_CONVERTOR_H

#include <iostream>
#include <sstream>
#include <vector>
#include <string>
#include <exception>

namespace dictp {

const std::string  ARRAY_SEP = ",";
const std::string ARRAY_NUM_SEP = ":";

template <typename T>
bool type_convert(const std::string& item, T* val) {
    std::stringstream ss;
    ss << item;
    ss >> *val;

    if (ss.fail()) {
        return false;
    }

    return true;
}

template <typename T>
bool type_convert(const std::string& item, std::vector<T>* array) {
    size_t offset, sep_pos = 0;
    int item_num = -1;

    if (std::string::npos == item.find(ARRAY_NUM_SEP)) {
        std::cerr << "Array num is not exist!" << std::endl;
        return false;
    }

    std::string str_num = item.substr(0, item.find(ARRAY_NUM_SEP));
    if (false == type_convert(str_num, &item_num)) {
        std::cerr << "Get array item num false!" << std::endl;
        return false;
    }

    (*array).reserve(item_num);
    std::string item_str = item.substr(item.find(ARRAY_NUM_SEP) + 1);

    while (std::string::npos != (offset = item_str.find(ARRAY_SEP, sep_pos))) {
        if (offset == sep_pos) {
            return true;
        }

        std::string val(item_str, sep_pos, offset - sep_pos);
        T arr_item;
        std::istringstream item_parser(val);

        if (!(item_parser >> arr_item)) {
            return false;
        }

        (*array).push_back(arr_item);
        sep_pos = offset + 1;
    }

    if (sep_pos < item_str.size()) {
        std::string val(item_str, sep_pos, item_str.size() - sep_pos);
        T arr_item;
        std::istringstream item_parser(val);

        if (!(item_parser >> arr_item)) {
            return false;
        }

        (*array).push_back(arr_item);
    }

    return true;
}
}  // namespace dictp

#endif // DICTP_STR_CONVERTOR_H

