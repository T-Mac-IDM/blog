/***************************************************************************
 * 
 * Copyright (c) 2015 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
 
 
 
/**
 * @file deserialize.cpp
 * @author liuzhaocheng(com@baidu.com)
 * @date 2015/08/25 14:09:20
 * @brief 
 *  
 **/

#include "parser/deserialize.h"
#include <stdlib.h>
#include <stdint.h>
#include <climits>
#include <errno.h>
#include <string>
#include <vector>
#include <iostream>

namespace dictp {

bool Deserialize::eol() {
    return _cur_pos == std::string::npos || _cur_pos >= _buffer.size();
}

void Deserialize::reset(const std::string& data) {
    _buffer = data;
    _cur_pos = 0;
}

bool Deserialize::next_col() {
    if (eol()) {
        return false;
    }
    std::size_t found = 0;
    if (_cur_pos == 0) {
        found = _buffer.find("\t", _cur_pos);
        if (found == 0) {
            std::cerr << "begin with \\t " << std::endl;
            return false;
        }
        _sub_str.assign(_buffer.substr(_cur_pos, found - _cur_pos));
    } else {
        found = _buffer.find("\t", _cur_pos + 1);
        _sub_str.assign(_buffer.substr(_cur_pos + 1, found - _cur_pos - 1));
    }
    if (_buffer[_cur_pos] == '\t' && found == _cur_pos + 1) {
        return false;
    }
    _cur_pos = found;
    return true;
}

}

