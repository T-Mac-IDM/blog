/***************************************************************************
 * 
 * Copyright (c) 2015 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
 
 
 
/**
 * @file deserialize.h
 * @author liuzhaocheng(com@baidu.com)
 * @date 2015/08/25 11:03:33
 * @brief 
 *  
 **/

#ifndef  DICTP_DESERIALIZE_H
#define  DICTP_DESERIALIZE_H

#include <stdlib.h>
#include <stdint.h>
#include <climits>
#include <errno.h>
#include <string>
#include <vector>
#include <iostream>
#include <sstream>
#include <typeinfo>
#include "parser/str_convertor.h"

namespace dictp {

//Deserialize one line
class Deserialize {
public:
    explicit Deserialize(const std::string& buffer) :
        _buffer(buffer), _cur_pos(0), _sub_str() {}

    explicit Deserialize() :
        _buffer(), _cur_pos(std::string::npos) {}

    ~Deserialize() {}

public:
    // is the line is over
    // @return true the line is parsed
    bool eol();

    // reset _buffer and _cur_pos 
    // @param line content to be parsed
    void reset(const std::string& data);

    // get next column in the line
    // @return true only if find a not null column
    bool next_col();

    template <typename G>
    bool parse_user_item(G* g) {
        if (!next_col()) {
            return false;
        }
        if (g->parse(_sub_str)) {
            return true;
        }
    }

    template <typename T>
    bool parse_item(T* val) {
        if (!next_col()) {
            return false;
        }
        if (dictp::type_convert(_sub_str, val)) {
            return true;
        }
    }

private:
    std::string _buffer;
    std::size_t _cur_pos;
    std::string _sub_str;
};
} //namespace dictp

#endif  //DICTP_DESERIALIZE_H
