/***************************************************************************
 * 
 * Copyright (c) 2015 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
 
 
 
/**
 * @file sample/sample.h
 * @author liuzhaocheng(com@baidu.com)
 * @date 2015/08/27 11:20:33
 * @brief 
 *  
 **/

#ifndef  USERDEF_SAMPLE_SAMPLE_H 
#define  USERDEF_SAMPLE_SAMPLE_H 

#include <string>
#include <vector>

namespace userdef {
class Sample {
public:

    bool parse(const std::string str);
};

}
#endif  //__SAMPLE/SAMPLE_H_
