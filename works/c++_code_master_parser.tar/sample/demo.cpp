/***************************************************************************
 * 
 * Copyright (c) 2015 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
 
 
 
/**
 * @file demo.cpp
 * @author liuzhaocheng(com@baidu.com)
 * @date 2015/08/26 15:00:57
 * @brief 
 *  
 **/

#include <iostream>
#include <string>
#include <vector>
#include "parser/parser_controller.h"
#include "sample/sample.h"

template <typename T>
void print_arr(std::vector<T> t) {
    std::cout << "array [ " << std::endl;
    for (int index = 0; index < t.size(); index++) {
        std::cout << t[index] << std::endl;
    }
    std::cout << " ] " << std::endl;
}

int main() {

    ::dictp::ParseController pc("sample/dict");
    while (!pc.eof()) {
        std::cout << std::endl;
        std::cout << "line num is " << pc.get_nr()  << std::endl;

        int integer = 0;
        if (!pc.parse_support(&integer)) {
            std::cerr << "parsing error!" << std::endl;
        }
        std::cout << integer << std::endl;

        float f = 0;
        if (!pc.parse_support(&f)) {
            std::cerr << "parsing error!" << std::endl;
        }
        std::cout << f << std::endl;

        std::vector<int> vi;
        if (!pc.parse_support(&vi)) {
            std::cerr << "parsing error!" << std::endl;
        }
        print_arr(vi);

        std::vector<float> vf;
        if (!pc.parse_support(&vf)) {
            std::cerr << "parsing error!" << std::endl;
        }
        print_arr(vf);

        std::string s;
        if (!pc.parse_support(&s)) {
            std::cerr << "parsing error!" << std::endl;
        }
        std::cout << s << std::endl;

        std::vector<std::string> ss;
        if (!pc.parse_support(&ss)) {
            std::cerr << "parsing error!" << std::endl;
        }
        print_arr(ss);

        ::userdef::Sample sam;
        if (!pc.parse_user(&sam)) {
            std::cerr << "parsing error!" << std::endl;
        }
    }
}





















/* vim: set expandtab ts=4 sw=4 sts=4 tw=100: */
