/***************************************************************************
 * 
 * Copyright (c) 2015 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
 
 
 
/**
 * @file sample/sample.cpp
 * @author liuzhaocheng(com@baidu.com)
 * @date 2015/08/27 10:37:14
 * @brief 
 *  
 **/

#include "sample/sample.h"
#include <iostream>
#include "parser/str_convertor.h"

namespace userdef {

    bool Sample::parse(const std::string str) {
        std::cout << "user define part [ " << std::endl;
        std::string content = str.substr(str.find("{") + 1, str.find("}") - str.find("{") - 1);
        std::vector<std::string> arr_string;
        ::dictp::type_convert(content, &arr_string);

        int integer = 0;
        ::dictp::type_convert(arr_string[0], &integer);
        std::cout << typeid(integer).name() << " " << integer << std::endl;

        float f = 0.0;
        ::dictp::type_convert(arr_string[1], &f);
        std::cout << typeid(f).name() << " " << f << std::endl;

        std::string s;
        ::dictp::type_convert(arr_string[2], &s);
        std::cout << typeid(s).name() << " " << s << std::endl;
        std::cout << " ] " << std::endl;
    }

}





















/* vim: set expandtab ts=4 sw=4 sts=4 tw=100: */
