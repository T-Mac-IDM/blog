#include <gtest/gtest.h>

#include <string>
#include <vector>
#include "parser/parser_controller.h"
#include "sample/sample.h"

int main(int argc, char *argv[]) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}

class TestDictParser : public ::testing::Test {
public:
    test_dict_parser() {}
    ~test_dict_parser() {} 

    virtual void SetUp() {}
    virtual void TearDown() {}
};

TEST_F(test_dict_parser, NormalParse) {
    ::dpse::FileParser dp("sample/dict");

    int i = 0;
    ASSERT_TRUE(dp.parse(&i));
    ASSERT_EQ(i, 2);

    float d = 0.0;
    ASSERT_TRUE(dp.parse(&d));
    ASSERT_FLOAT_EQ(d, 2.2);

    ::sample::Sample s;
    ASSERT_TRUE(dp.parse(&s));
    s.debug_info();

    std::string str;
    ASSERT_TRUE(dp.parse(&str));
    ASSERT_EQ(str, "cc");
        
    std::vector<int> vd;
    ASSERT_TRUE(dp.parse(&vd));
    for (size_t j = 0; j < vd.size(); j++) {
        ASSERT_DOUBLE_EQ(vd[j], (j + 1));
    }
}
