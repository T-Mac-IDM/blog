#include <gtest/gtest.h>

#include <string>
#include <vector>

#include "parser/deserialize.h"
#include "sample/sample.h"

int main(int argc, char *argv[]) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}

class TestParser : public ::testing::Test {
public:
    test_parser() {}
    ~test_parser() {}

    virtual void SetUp() {}
    virtual void TearDown() {}
};

TEST_F(test_parser, ParseEmptyData) {
    const std::string data("");
    ::dpse::Deserialize parser(data);

    int num = 0;
    ASSERT_FALSE(parser.deserialize(&num));
}

TEST_F(test_parser, ParseIntOfRigntForm) {
    const std::string data("1\t2\t3");
    ::dpse::Deserialize parser(data);

    int num = 0;
    for (int i = 0; i < 3; i++) {
        ASSERT_TRUE(parser.deserialize(&num));
        ASSERT_EQ(num, i + 1);
    }
}

TEST_F(test_parser, ParseFloatOfRightForm) {
    const std::string data("1.1\t2.1\t3.1");
    ::dpse::Deserialize parser(data);

    float f = 0;
    for (int i = 0; i < 3; ++i) {
        ASSERT_TRUE(parser.deserialize(&f));
        ASSERT_FLOAT_EQ(f, i + 1.1);
    }
}

TEST_F(test_parser, ParseStringOfRightForm) {
    const std::string data("aa\tbb\tcc");
    ::dpse::Deserialize parser(data);

    std::string str;
    ASSERT_TRUE(parser.deserialize(&str));
    ASSERT_EQ(str, "aa");
    ASSERT_TRUE(parser.deserialize(&str));
    ASSERT_EQ(str, "bb");
    ASSERT_TRUE(parser.deserialize(&str));
    ASSERT_EQ(str, "cc");
}

TEST_F(test_parser, ParseVecOfRightForm) {
    const std::string data("3:1,2\t3:1.1,2.1,3.1,4.1");
    ::dpse::Deserialize parser(data);
    
    std::vector<int> vi;
    ASSERT_TRUE(parser.deserialize(&vi));
    ASSERT_EQ(vi.size(), 2);
    for (int i = 0; i < vi.size(); ++i) {
        ASSERT_EQ(vi[i], i + 1);
    }
    std::vector<float> vf;
    ASSERT_TRUE(parser.deserialize(&vf));
    ASSERT_EQ(vf.size(), 3);
    for (int i = 0; i < vf.size(); ++i) {
        ASSERT_FLOAT_EQ(vf[i], i + 1.1);
    }
}

TEST_F(test_parser, ParseUDFOfRightForm) {
    const std::string data("2\t1.1\tcc\t2:1,2");
    ::dpse::Deserialize parser(data);

    ::sample::Sample s;
    ASSERT_TRUE(parser.deserialize(&s));
    s.debug_info();
}
