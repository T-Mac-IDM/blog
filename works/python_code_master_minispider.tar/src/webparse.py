#!/usr/bin/env python
# -*- coding: utf-8 -*-
################################################################################
#
# Copyright (c) 2015 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
This file contains class WebParseErr and class WebParse which parse webpage to
get new urls.

Authors: liuzhaocheng(liuzhaocheng@baidu.com)
Date:    2015/09/09 17:23:06
"""

import logging
import os
import re
import sgmllib
import time
import urlparse
import urllib2
import bs4

class WebParseErr(Exception):
    """
       wpe exception class
    """
    pass

class WebParse(object):
    """ get the html pages and parse them to get new urls.
        Attributes:
            cur_url: the url of cur html page.
            new_urls: a list of new urls in the page.
            page: the content of the html page.
            crawl_timeout: crawl time out.
            url_pattern: the pattern of urls that we need to save page.
            output_path: the path of output dir.
    """

    def __init__(self, cur_url, page_params, new_urls):
        """inits webparse's attributes."""
        self.cur_url = cur_url
        self.new_urls = new_urls
        self.page = ""
        self.crawl_timeout = page_params['crawl_timeout']
        self.url_pattern = page_params['url_pattern']
        self.output_path = page_params['output_path']
        logging.info("inited webParse")

    def write_target_page(self, page):
        """write the targeted page to output_path"""
        output_file = os.path.join(self.output_path, self.cur_url.replace('/', '\\'))
        try:
            writer = open(output_file, 'w')
        except IOError as e:
            logging.error('%s error occurs while writing target url page to disk' % e)
            raise WebParseErr(e)
        writer.write(page)
        writer.close()

    def get_page(self):
        """get the specify url's html page
        get page by urllib2.urlopen, then match the url with url_pattern. If matched, write
        the page to the disk. Finally get the content of the page in utf8.

        Returns:
            If get page and decode successfully, return True.
            Else return false.

        Raises: WebParseErr
        """
        try:
            logging.info('get page from url : %s' % (self.cur_url))
            f = urllib2.urlopen(self.cur_url, timeout=float(self.crawl_timeout))
        except (urllib2.URLError, urllib2.HTTPError, ValueError) as e:
            logging.fatal('get page from url : %s failed! detail: %s ' % (self.cur_url, e))
            raise WebParseErr('get page from url : %s failed! detail: %s' % (self.cur_url, e))

        page = f.read()
        f.close()
        if self.match_url(self.cur_url, self.url_pattern):
            try:
                self.write_target_page(page)
            except WebParseErr as e:
                logging.error('write target page is fail with %s error' % e)

        #charset of page
        types = ['utf8', 'gbk', 'gb2312', 'iso-8859-1']
        for type in types:
            try:
                self.decode_page = page.decode(type).encode('utf8')
            except UnicodeDecodeError as e:
                continue
            return True
        return False

    def url_format(self, url):
        """change the relative url path to absolute url path"""
        if url.find('"') >= 0:
            url = url.split('"')[1]
        return urlparse.urljoin(self.cur_url, url).encode('utf8')

    def parse_a(self, soup):
        """parse html doc to find label a"""
        for tag_a in soup.findAll('a'):
            try:
                self.new_urls.append(self.url_format(tag_a['href']))
            except KeyError as e:
                logging.warn('this a tag has no href! url is [%s]...'
                    % self.cur_url)
                pass

    def parse_img(self, soup):
        """parse html doc to find label img"""
        for tag_img in soup.findAll('img'):
            try:
                self.new_urls.append(self.url_format(tag_img['src']))
            except KeyError as e:
                logging.warn('this img tag has no href! url is [%s]'
                    % self.cur_url)
                pass

    def parse(self):
        """parse html doc to get new urls
        Parse the html by beautifulsoup, parse tag a and tag img to
        get new urls.

        Returns:
           If the content is null, return false.
           If the content is not null, and has been parsed, return true.
        """
        if self.decode_page == "":
            logging.error('page is null, url is %s' % self.cur_url)
            return False
        soup = bs4.BeautifulSoup(self.decode_page, 'html.parser')
        pretty_html = soup.prettify()
        soup = bs4.BeautifulSoup(pretty_html, 'html.parser')
        self.parse_a(soup)
        self.parse_img(soup)
        return True

    def run(self):
        """overall function to use webparse.
        First get the content of current url, then parse the content.

        Returns:
            If there's exist errors during get_page and parse the page, then return false.
            Else return true.

        Raise:
            WebParseErr: while getting page and parsing page.
        """
        logging.info("begin handle %s ... " % self.cur_url)
        logging.info("geting page ...")
        try:
            if self.get_page():
                if self.parse():
                    return True
                else:
                    logging.error("error occurs while getting sub urls")
                    return False
            else:
                logging.fatal('error occurs when getting %s \'s page' % self.cur_url)
                return False
        except WebParseErr as e:
            raise WebParseErr(e)

    def match_url(self, url, pattern):
        """judging url if this is target url or not"""
        match_flag = re.match(pattern, url)
        if match_flag is not None:
            return True
        else:
            return False














