#!/usr/bin/env python
# -*- coding: utf-8 -*-
################################################################################
#
# Copyright (c) 2015 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
This file contains class SpiderThread which crawl the specified url.

Authors: liuzhaocheng(liuzhaocheng@baidu.com)
Date:    2015/09/09 17:23:06
"""

import time
import threading
import src.webparse
import logging

class SpiderThread(threading.Thread):
    """spider thread class which is the work thread.
       Attributes:
            page_param: the param of the page.
            cur_status: a data structure to save current status.
            max_depth: the maximum depth of this crawling.
            is_end: the flag that controll wheather this thread keep working.
            id: a unique identify of this thread.
    """

    def __init__(self, id, page_param, cur_status):
        """inits spiderThread's attributes"""
        super(SpiderThread, self).__init__()
        self.page_param = page_param
        self.cur_status = cur_status
        self.max_depth = page_param['max_depth']
        self.is_end = 1
        self.id = id

    def get_url(self):
        """get a url which is not crawled or crawling"""
        url = ''
        lists = self.cur_status['wait']
        lock = self.cur_status['mutex']
        lock.acquire()
        if len(lists) != 0:
            url = lists[0][0]
            self.cur_status['tryed'].add(url)
            self.cur_depth = lists[0][1]
            lists.remove(lists[0])
        lock.release()
        return url

    def run(self):
        """extract new urls from target url and update cur_status
        parse page to get new urls and update spider's current status.
        """
        new_urls = []
        mutex = self.cur_status['mutex']
        succ = self.cur_status['success']
        fail = self.cur_status['fail']
        wait = self.cur_status['wait']
        tryed = self.cur_status['tryed']
        while self.is_end == 1:
            url = self.get_url()
            if url == '':
                continue
            webpage_handle = src.webparse.WebParse(url, self.page_param, new_urls)
            try:
                logging.info("url is %s, thread is %s, cur depth is %s"
                    % (self.id, url, self.cur_depth))
                flag = webpage_handle.run()
            except src.webparse.WebParseErr as e:
                logging.fatal("exception occurs while deal with url [%s],"
                    "exception message is [%s]"
                    % (url, e))
                mutex.acquire()
                fail.add(url)
                mutex.release()
                flag = False

            if flag:
                mutex.acquire()
                succ.add(url)
                for u in new_urls:
                    if u not in succ and u not in fail \
                        and self.cur_depth + 1 <= self.max_depth \
                        and u not in tryed:
                        wait.append((u, self.cur_depth + 1))
                mutex.release()
                logging.info('deal with url successfully, url is %s' % url)
            else:
                logging.info('fail to deal with url, url is %s' % url)















