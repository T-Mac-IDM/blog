#!/usr/bin/env python
# -*- coding: utf-8 -*-
################################################################################
#
# Copyright (c) 2015 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
This file contains class SpiderErr and class Spider which control class SpiderThread
to crawl urls.

Authors: liuzhaocheng(liuzhaocheng@baidu.com)
Date:    2015/09/09 17:23:06
"""

import ConfigParser
import logging
import os
import threading
import time

import src.webparse
import src.spider_thread

class SpiderErr(Exception):
    """
        spider exception class
    """
    pass

class Spider(object):
    """
        crawl webpage on Breadth first traversal
        Attributes:
            conf: file path of the conf file.
            cur_status: a data structure to store current status.
            thread_pool: a pool that stores all working threads.
    """

    def __init__(self, conf):
        """init spider class"""
        self.conf = conf
        self.cur_status = {'tryed': set(),
            'wait': [],
            'success': set(),
            'fail': set(),
            'mutex': threading.Lock()
            }
        self.thread_pool = []
        logging.info('Inited spider with no errors!')

    def init_spider_config(self):
        """init spider config by config file"""
        conf = ConfigParser.ConfigParser()
        conf.read(self.conf)
        try:
            self.url_list_file = conf.get('spider', 'url_list_file')
            self.output_path = conf.get('spider', 'output_directory')
            self.max_depth = conf.getint('spider', 'max_depth')
            self.crawl_interval = conf.getint('spider', 'crawl_interval')
            self.crawl_timeout = conf.getint('spider', 'crawl_timeout')
            self.url_pattern = conf.get('spider', 'target_url')
            self.thread_count = conf.get('spider', 'thread_count')
        except (ConfigParser.NoSectionError, ConfigParser.NoOptionError, ValueError) as e:
            logging.fatal('While reading Configuration occurs [%e] error!' % e)
            raise SpiderErr(e)
        else:
            logging.info('successfully init spider conf')

    def crawl(self):
        """the main function of crawling.
        starts all working threads to crawl and ends all working threads
        at the end.
        Raises:
            SpiderErr when fail to open the seed url file defined in conf file
        """
        try:
            seeds = open(self.url_list_file, 'r')
        except IOError as ioe:
            seeds.close()
            logging.fatal('fail to open file in [%s] with [%s] error!'
                % (self.url_list_file, ioe))
            raise SpiderErr('fail to open file in [%s] with [%s] error!'
                % (self.url_list_file, ioe))

        for line in seeds:
            url = line.strip()
            if url not in self.cur_status['wait']:
                self.cur_status['wait'].append((url, 0))
        seeds.close()
        logging.info('url list inited !')
        depth = 0
        self.start_all_threads()
        time.sleep(3)
        while len(self.cur_status['wait']) != 0:
            time.sleep(3)
        self.end_all_threads()

    def end_all_threads(self):
        """end all worker threads"""
        for thread in self.thread_pool:
            thread.is_end = 0

    def start_all_threads(self):
        """start all work threads to crawl"""
        page_param = {}
        page_param['crawl_timeout'] = self.crawl_timeout
        page_param['url_pattern'] = self.url_pattern
        page_param['output_path'] = self.output_path
        page_param['max_depth'] = self.max_depth
        for i in range(int(self.thread_count)):
            thread = src.spider_thread.SpiderThread(i, page_param, self.cur_status)
            self.thread_pool.append(thread)
            thread.start()






