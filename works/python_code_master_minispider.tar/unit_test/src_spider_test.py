#!/usr/bin/env python
# -*- coding: utf-8 -*-
########################################################################
#
# Copyright (c) 2015 Baidu.com, Inc. All Rights Reserved
#
########################################################################

"""
 * @file src_spider_test.py
 * @author liuzhaocheng(com@baidu.com)
 * @date 2015/08/31 17:36:17
 * @brief
 *
"""

import copy
import os
import sys
import shutil
import unittest

import mini_spider
import src.spider

class SpiderTest(unittest.TestCase):
    """
        test spider class
    """
    def setUp(self):
        """
            preprocess before case
        """
        if os.path.isdir('./log'):
            shutil.rmtree('./log')
            os.makedirs('./log')
        if os.path.isdir('./output'):
            shutil.rmtree('./output')
            os.makedirs('./output')
        mini_spider.init_log('./log/src_spider_test.log')

    def tearDown(self):
        """
            postprocess after case
        """
        pass

    def single_thread_test(self):
        """
            test spider single thread
        """
        spider = src.spider.Spider('./conf/spider.conf')
        spider.init_spider_config()
        cur_url = 'http://pycm.baidu.com:8081/'
        next_layer_url_list = ['http://pycm.baidu.com:8081/page1.html',
                               'http://pycm.baidu.com:8081/page2.html',
                               'http://pycm.baidu.com:8081/page3.html',
                               'http://pycm.baidu.com:8081/mirror/index.html',
                               'http://pycm.baidu.com:8081/page4.html']
        done_url_list = ['http://pycm.baidu.com:8081/']
        spider.single_thread(cur_url)
        for thread in spider.thread_pool:
            thread.join(30)

        self.asserEqual(spider.cur_status['succ_url'], done_url_list,
                        "cur_status['succ_url'] is wrong")
        self.asserEqual(spider.cur_status['next_layer_url'], next_layer_url_list,
                        "cur_status['next_layer_url'] is wrong")

    def muti_thread_crawler_test(self):
        """
            test spider multi thread crawler
        """
        spider = src.spider.Spider('./conf/spider.conf')
        spider.init_spider_config()
        spider.cur_status['cur_layer_url'] = ['http://pycm.baidu.com:8081/page1.html',
                                              'http://pycm.baidu.com:8081/page2.html']

        done_url_list = ['http://pycm.baidu.com:8081/page1.html',
                         'http://pycm.baidu.com:8081/page2.html']
        next_layer_url_list = copy.deepcopy(sorted(['http://pycm.baidu.com:8081/1/page1_4.html',
                               'http://pycm.baidu.com:8081/1/page1_1.html',
                               'http://pycm.baidu.com:8081/1/page1_2.html',
                               'http://pycm.baidu.com:8081/1/page1_3.html',
                               'http://pycm.baidu.com:8081/page2_1.html',
                               'http://pycm.baidu.com:8081/2/index.html'
                               ]))
        spider.multi_thread_crawler()
        res_done_url_list = copy.deepcopy(sorted(spider.cur_status['succ_url']))
        res_next_layer_url = copy.deepcopy(sorted(spider.cur_status['next_layer_url']))
        self.assertEqual(res_done_url_list, done_url_list,
                         "multi_thread_crawler is not right")
        self.asserEqual(res_next_layer_url, next_layer_url_list,
                        "multi_thread_crawler is not right")

    def update_cur_layer(self):
        """
            test spider update cur layers function
        """
        spider = src.spider.Spider('./conf/spider.conf')
        spider.init_spider_config()
        spider.cur_status['cur_layer_url'] = ['http://pycm.baidu.com:8081/page1.html',
                                              'http://pycm.baidu.com:8081/page2.html']

        spider.cur_status['succ_url'] = ['http://pycm.baidu.com:8081/page1.html',
                                         'http://pycm.baidu.com:8081/page2.html']
        spider.cur_status['next_layer_url'] = ['http://pycm.baidu.com:8081/1/page1_4.html',
                                               'http://pycm.baidu.com:8081/2/index.html']

        true_cur_layer_url_list = ['http://pycm.baidu.com:8081/1/page1_4.html',
                                   'http://pycm.baidu.com:8081/2/index.html']
        spider.update_cur_layer()
        self.assertEqual(spider.cur_status['cur_layer_url'], true_cur_layer_url_list,
                         "update_cur_layer is not right")

if __name__ == '__main__':
    unittest.main()








