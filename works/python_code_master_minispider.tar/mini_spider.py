#!/usr/bin/env python
# -*- coding: utf-8 -*-
################################################################################
#
# Copyright (c) 2015 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
This file contains the main function of minispider and init_log function which
provides a convenient way to save spider log.

Authors: liuzhaocheng(liuzhaocheng@baidu.com)
Date:    2015/09/09 17:23:06
"""

import logging
import logging.handlers
import optparse
import os
import sys
import shutil

import src.spider

def init_log(log_path, level=logging.INFO, when="D", backup=7,
             format="%(levelname)s: %(asctime)s: %(filename)s:%(lineno)d * %(thread)d %(message)s",
             datefmt="%m-%d %H:%M:%S"):
    """
    init_log - initialize log module

    Args:
      log_path      - Log file path prefix.
                      Log data will go to two files: log_path.log and log_path.log.wf
                      Any non-exist parent directories will be created automatically
      level         - msg above the level will be displayed
                      DEBUG < INFO < WARNING < ERROR < CRITICAL
                      the default value is logging.INFO
      when          - how to split the log file by time interval
                      'S' : Seconds
                      'M' : Minutes
                      'H' : Hours
                      'D' : Days
                      'W' : Week day
                      default value: 'D'
      format        - format of the log
                      default format:
                      %(levelname)s: %(asctime)s: %(filename)s:%(lineno)d * %(thread)d %(message)s
                      INFO: 12-09 18:02:42: log.py:40 * 139814749787872 HELLO WORLD
      backup        - how many backup file to keep
                      default value: 7

    Raises:
        OSError: fail to create log directories
        IOError: fail to open log file
    """
    formatter = logging.Formatter(format, datefmt)
    logger = logging.getLogger()
    logger.setLevel(level)

    dir = os.path.dirname(log_path)
    if not os.path.isdir(dir):
        os.makedirs(dir)

    handler = logging.handlers.TimedRotatingFileHandler(log_path + ".log",
                                                        when=when,
                                                        backupCount=backup)
    handler.setLevel(level)
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    handler = logging.handlers.TimedRotatingFileHandler(log_path + ".log.wf",
                                                        when=when,
                                                        backupCount=backup)
    handler.setLevel(logging.WARNING)
    handler.setFormatter(formatter)
    logger.addHandler(handler)


def clean():
    """
        remove previous output and log dir
    """
    conf = ConfigParser.ConfigParser()
    conf.read('./log/spider.log')
    output_p = ''
    try:
        output_p = conf.get('spider', 'output_directory')
    except (ConfigParser.NoSectionError, ConfigParser.NoOptionError, ValueError) as e:
        logging.fatal('While reading Configuration occurs [%e] error!' % e)
        return None
    if output_p != '':
        if os.path.isdir(output_p):
            shutil.rmtree(output_p)
            os.makedirs(output_p)
    else:
        print 'output dir is not specify in conf file!'
    log_p = './log'
    if os.path.isdir(log_p):
        shutil.rmtree(log_p)
        os.makedirs(log_p)


def main():
    """
        main function
    """
    #初始化抓取日志
    init_log('./log/spider.log')
    logging.info('Inited log')

    #解析命令行参数
    parser = optparse.OptionParser(usage='%prog [-h] [-v] [-c conf] [-cl clean]')
    parser.add_option('-v', '--version', action='store_true',
        dest='version', help='show version info')
    parser.add_option('-c', '--conf', action='store', dest='conf',
        default='spider.conf', metavar='spider.conf',
        help='specify the conf file, then run spider')
    parser.add_option('-l', '--clean', action='store_true', dest='clean',
        help='rm -rf previous output and log dir')
    options, args = parser.parse_args()

    #版本信息和删除output和log的命令
    if options.version:
        logging.info('python code master mini_spider 1.0')
        return None
    if options.clean:
        clean()
        logging.info('previous output and log dir is removed.')
        return None

    #指定抓取的配置文件或者不指定采取默认的命令

    #启动spider
    logging.info('try to run the spider ..')
    try:
        spider = src.spider.Spider(options.conf)
        spider.init_spider_config()
        spider.crawl()
        logging.info('spider done. with no errors')
    except src.spider.SpiderErr:
        loggin.fatal('spider failed')
    finally:
        logging.info('All program done')

if __name__ == "__main__":
    main()



















# vim: set expandtab ts=4 sw=4 sts=4 tw=100: */
